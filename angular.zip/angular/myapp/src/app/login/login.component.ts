import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  loginForm !: FormGroup;
  signupForm !: FormGroup;

  constructor(
    private fb: FormBuilder,
  ) {

  }

  loginSubmit() {
    if (this.loginForm.valid) {
      let userData = JSON.stringify(this.loginForm.value);
      localStorage.setItem('user', userData);
    }
  }

  signupSubmit() {
    if (this.signupForm.valid) {
      let userData = JSON.stringify(this.signupForm.value);
      localStorage.setItem('user', userData);
    }
  }

  createLoginForm() {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  createSignupForm() {
    this.signupForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      phoneNumber: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    })
  }

  ngOnInit() {
    this.createLoginForm();
    this.createSignupForm();
  }
}
